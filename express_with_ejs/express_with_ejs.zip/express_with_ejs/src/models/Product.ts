export interface Product {
    id?: number;
    time?: string;
    celcius?: string;
    moisture?: string;
    volt?: string;
}
